package com.Tapia.ProyectoResidencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoResidenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
